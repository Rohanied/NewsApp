package com.example.newsapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class PageAdapter extends FragmentStatePagerAdapter {

    int NumberOfTabs;

    public PageAdapter(@NonNull FragmentManager fm, int numberOfTabs) {
        super(fm);
        this.NumberOfTabs=numberOfTabs;

    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0: return new TopHeadlines();
            case 1: return new Businesss();
            case 2: return new Entertainment();
            case 3: return new Health();
            case 4: return new Science();
            case 5: return new Sports();
            case 6: return new Technology();
            default:return null;
        }
    }

    @Override
    public int getCount() {
        return NumberOfTabs;
    }
}
